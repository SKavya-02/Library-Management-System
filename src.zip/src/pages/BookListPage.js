// src/pages/BookListPage.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const BookListPage = () => {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const res = await axios.get(`https://localhost:7093/api/Book/all`);
      setBooks(res.data);
    } catch (error) {
      setMessage('Failed to load books.');
    }
  };

  const handleSearch = async () => {
    try {
      const res = await axios.get(`https://localhost:7093/api/Book/all?search=${search}`);
      setBooks(res.data);
    } catch (error) {
      setMessage('Search failed.');
    }
  };

  return (
    <div className="container mt-5">
      <h3 className="mb-4 text-center">📚 All Available Books</h3>
      
      <div className="input-group mb-4">
        <input
          type="text"
          className="form-control"
          placeholder="Search by title or author..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button className="btn btn-primary" onClick={handleSearch}>🔍 Search</button>
      </div>

      {message && <div className="alert alert-danger">{message}</div>}

      <div className="row">
        {books.length === 0 && <p>No books found.</p>}
        {books.map((book) => (
          <div key={book.id} className="col-md-3 mb-4">
            <div className="card h-100 shadow-sm">
              <img src={book.imageUrl || "https://via.placeholder.com/150"} className="card-img-top" alt={book.title} />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{book.title}</h5>
                <p className="card-text">{book.author}</p>
                <p className="card-text text-muted">{book.language} | ₹{book.cost}</p>
                <button className="btn btn-outline-primary mt-auto">📖 Borrow</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookListPage;
