import React from 'react';

const BookInsightsPage = () => {
  return (
    <div className="container mt-4">
      <h2>📊 Book Insights (Admin Only)</h2>
      <p>Track most viewed, borrowed, and liked books here.</p>
      
    </div>
  );
};

export default BookInsightsPage;
