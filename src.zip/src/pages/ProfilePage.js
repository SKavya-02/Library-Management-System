// src/pages/Profile.jsx
import React, { useState, useEffect } from "react";
import axios from "axios";

const Profile = () => {
  const [profile, setProfile] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    gender: "",
    profilePicture: ""
  });

  const [passwords, setPasswords] = useState({
    current: "",
    newPass: "",
    confirmNew: "",
  });

  const [imagePreview, setImagePreview] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isPasswordEditing, setIsPasswordEditing] = useState(false);
  const [lastPasswordChange] = useState(new Date().toLocaleDateString());
  const token = localStorage.getItem("userToken");

  const userId = 2; 

  // Fetch profile on load
  useEffect(() => {
    if (userId) {
      axios.get(`https://localhost:7093/api/User/search?search=kavya`, {
        headers: {Authorization: `Bearer ${localStorage.getItem("userToken")}`, }
      })
      .then(res => {
        setProfile(res.data);
        if (res.data.profilePicture) {
          setImagePreview(`https://localhost:7093${res.data.profilePicture}`);
        }
      })
      .catch(err => console.error("Failed to fetch profile:", err));
    }
  }, [userId, token]);

  const handleProfileChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handlePasswordChange = (e) => {
    setPasswords({ ...passwords, [e.target.name]: e.target.value });
  };

  const handleImageUpload = (e) => {
    if (e.target.files && e.target.files[0]) {
      setImagePreview(URL.createObjectURL(e.target.files[0]));
      uploadProfilePicture(e.target.files[0]);
    }
  };

  const uploadProfilePicture = async (file) => {
    try {
      const formData = new FormData();
      formData.append("file", file);

      await axios.post(
        `https://localhost:7093/api/User/upload-profile-picture/${userId}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("userToken")}`,
            
          },
        }
      );
      alert("Profile picture updated successfully!");
    } catch (error) {
      console.error("Error uploading profile picture:", error);
      alert("Failed to upload profile picture");
    }
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(
        `https://localhost:7093/api/User/update-user/10`,
        profile,
        {
          headers: { Authorization: `Bearer ${localStorage.getItem("userToken")}`, },
        }
      );
      setIsEditing(false);
      alert("Profile updated successfully!");
    } catch (error) {
      console.error("Update failed:", error);
      alert("Profile updated successfully!");
    }
  };

  const handlePasswordSubmit = (e) => {
    e.preventDefault();
    if (passwords.newPass !== passwords.confirmNew) {
      alert("New passwords don't match!");
      return;
    }
    // Implement password change API if available
    setIsPasswordEditing(false);
    setPasswords({ current: "", newPass: "", confirmNew: "" });
    alert("Password changed successfully!");
  };

  return (
    <div className="container-fluid py-4">
      {/* Profile Picture & Info */}
      <div className="row mb-4">
        <div className="col-lg-4 mb-4">
          <div className="card shadow-sm h-100 text-center p-4">
            <div className="position-relative mx-auto" style={{ width: "120px" }}>
              <img
                src={imagePreview || "https://dummyimage.com/150x150/cccccc/ffffff&text=Profile"}
                alt="Profile"
                className="rounded-circle mb-3 img-thumbnail"
                style={{ width: "120px", height: "120px", objectFit: "cover" }}
              />
              <label
                className="position-absolute bottom-0 end-0 bg-primary text-white rounded-circle p-2"
                style={{ width: "32px", height: "32px", cursor: "pointer" }}
              >
                <i className="bi bi-camera"></i>
                <input
                  type="file"
                  className="d-none"
                  onChange={handleImageUpload}
                  accept="image/*"
                />
              </label>
            </div>
            <h4 className="card-title mt-3">{profile.fullName}</h4>
            <p className="text-muted">
              <i className="bi bi-envelope me-2"></i>{profile.email}
            </p>
            <p className="text-muted">
              <i className="bi bi-telephone me-2"></i>{profile.phone}
            </p>
          </div>
        </div>

        {/* Personal Info */}
        <div className="col-lg-8 mb-4">
          <div className="card shadow-sm">
            <div className="card-header bg-white d-flex justify-content-between align-items-center">
              <h5><i className="bi bi-pencil-square me-2"></i>Personal Information</h5>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className={`btn btn-sm ${isEditing ? "btn-outline-danger" : "btn-outline-primary"}`}
              >
                {isEditing ? "Cancel" : "Edit"}
              </button>
            </div>
            <div className="card-body">
              <form onSubmit={handleProfileSubmit}>
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label>Full Name</label>
                    <input type="text" className="form-control"
                      name="fullName"
                      value={profile.fullName}
                      onChange={handleProfileChange}
                      disabled={!isEditing} />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label>Email</label>
                    <input type="email" className="form-control"
                      name="email"
                      value={profile.email}
                      onChange={handleProfileChange}
                      disabled={!isEditing} />
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label>Phone</label>
                    <input type="tel" className="form-control"
                      name="phone"
                      value={profile.phone}
                      onChange={handleProfileChange}
                      disabled={!isEditing} />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label>Address</label>
                    <input type="text" className="form-control"
                      name="address"
                      value={profile.address || ""}
                      onChange={handleProfileChange}
                      disabled={!isEditing} />
                  </div>
                </div>
                {isEditing && (
                  <div className="text-end">
                    <button type="submit" className="btn btn-primary">
                      Save Changes
                    </button>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>

        {/* Password Settings */}
        <div className="col-12">
          <div className="card shadow-sm">
            <div className="card-header bg-white d-flex justify-content-between align-items-center">
              <h5><i className="bi bi-shield-lock me-2"></i>Password Settings</h5>
              <button
                onClick={() => setIsPasswordEditing(!isPasswordEditing)}
                className={`btn btn-sm ${isPasswordEditing ? "btn-outline-danger" : "btn-outline-primary"}`}
              >
                {isPasswordEditing ? "Cancel" : "Change Password"}
              </button>
            </div>
            <div className="card-body">
              {isPasswordEditing ? (
                <form onSubmit={handlePasswordSubmit}>
                  <div className="row">
                    <div className="col-md-4">
                      <label>Current Password</label>
                      <input type="password" name="current"
                        value={passwords.current} onChange={handlePasswordChange}
                        className="form-control" required />
                    </div>
                    <div className="col-md-4">
                      <label>New Password</label>
                      <input type="password" name="newPass"
                        value={passwords.newPass} onChange={handlePasswordChange}
                        className="form-control" required />
                    </div>
                    <div className="col-md-4">
                      <label>Confirm New Password</label>
                      <input type="password" name="confirmNew"
                        value={passwords.confirmNew} onChange={handlePasswordChange}
                        className="form-control" required />
                    </div>
                  </div>
                  <div className="text-end mt-3">
                    <button type="submit" className="btn btn-primary">Update Password</button>
                  </div>
                </form>
              ) : (
                <p className="text-muted">Last changed: {lastPasswordChange}</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
