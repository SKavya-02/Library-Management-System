// src/pages/BookDetails.jsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const BookDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [borrowDate, setBorrowDate] = useState('2025-08-13')

  const fetchBookDetails = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get(
        `https://localhost:7093/api/Book/all`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("userToken")}`,
          },
        }
      );

      // Find the book by id
      const foundBook = response.data.find(
        (b) => String(b.bookId) === String(id)
      );
      setBook(foundBook || null);
    } catch (error) {
      console.error("Error fetching book details:", error);
      setBook(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBookDetails();
  }, [id]);

  const handleBorrow = async () => {
  try {

    let obj = {
      userId: 2,
      bookId: book.bookId,
      borrowedDate: new Date().toISOString()
    };

    await axios.post(
      `https://localhost:7093/api/Borrow/borrow`,
      obj,
      {
        headers: {
         Authorization: `Bearer ${localStorage.getItem("userToken")}`,
        },
      }
    );

    alert("Book borrowed successfully!");
    navigate("/dashboard");
  } catch (error) {
    console.error("Error borrowing book:", error);
    alert("Failed to borrow the book. Please try again.");
  }
};


  const handleReserve = async () => {
  try {

    let obj = {
      userId: 2,
      bookId: book.bookId,
      reservationDate: new Date().toISOString()
    };

    await axios.post(
      `https://localhost:7093/api/Reservation/reserve`,
      obj,
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("userToken")}`,
        },
      }
    );

    alert("Book reserved successfully!");
    navigate("/dashboard");
  } catch (error) {
    console.error("Error reserving book:", error);
    alert("Failed to reserve the book. Please try again.");
  }
};


  if (isLoading) {
    return (
      <div className="container py-5 text-center">
        <div className="spinner-border text-primary" role="status"></div>
        <p className="mt-2">Loading book details...</p>
      </div>
    );
  }

  if (!book) {
    return (
      <div className="container py-5 text-center">
        <h4>Book not found 📭</h4>
        <button
          onClick={() => navigate(-1)}
          className="btn btn-outline-secondary mt-3"
        >
          Back to Catalogue
        </button>
      </div>
    );
  }

  return (
    <div className="container py-4">
      <button
        onClick={() => navigate(-1)}
        className="btn btn-outline-secondary mb-4"
      >
        <i className="bi bi-arrow-left me-2"></i>Back to Catalogue
      </button>

      <div className="card shadow-sm border-0">
        <div className="row g-0">
          <div className="col-md-4 p-4 text-center bg-light">
            <img
              src= "https://dummyimage.com/200x300/cccccc/000000&text=Book+Cover"
              alt={book.title}
              className="img-fluid rounded shadow"
              style={{ maxHeight: "400px", objectFit: "contain" }}
            />
            <div className="mt-3">
              {/* Dummy static stars for now */}
              {[...Array(5)].map((_, i) => (
                <i
                  key={i}
                  className={`bi bi-star${
                    i < 4 ? "-fill" : ""
                  } text-warning me-1`}
                ></i>
              ))}
              <span className="text-muted ms-1">(4.0)</span>
            </div>
          </div>

          <div className="col-md-8">
            <div className="card-body p-4">
              <h2 className="card-title">{book.title}</h2>
              <p className="text-muted mb-4">by {book.author}</p>

              <div className="row mb-4">
                <div className="col-md-6">
                  <p>
                    <strong>Category ID:</strong>{" "}
                    <span className="badge bg-light text-dark">
                      {book.categoryId}
                    </span>
                  </p>
                  <p>
                    <strong>Language:</strong>{" "}
                    <span className="badge bg-light text-dark">
                      {book.language}
                    </span>
                  </p>
                  <p>
                    <strong>Publisher:</strong> {book.publisher}
                  </p>
                  <p>
                    <strong>Published Date:</strong>{" "}
                    {new Date(book.publicationDate).toLocaleDateString()}
                  </p>
                </div>
                <div className="col-md-6">
                  <p>
                    <strong>Edition:</strong> {book.edition}
                  </p>
                  <p>
                    <strong>Pages:</strong> {book.numberOfPages}
                  </p>
                  <p>
                    <strong>ISBN:</strong> {book.isbn}
                  </p>
                  <p>
                    <strong>Cost:</strong> ₹{book.cost}
                  </p>
                </div>
              </div>

              <div className="mb-4">
                <h5 className="mb-2">Description</h5>
                <p className="card-text">{book.description}</p>
              </div>

              <div className="d-flex gap-2 mt-4">
                <button
                  className="btn btn-success px-4"
                  onClick={handleBorrow}
                >
                  <i className="bi bi-book me-2"></i>Borrow Now
                </button>
                <button
                  className="btn btn-warning px-4"
                  onClick={handleReserve}
                >
                  <i className="bi bi-calendar-check me-2"></i>Reserve
                </button>
                <button className="btn btn-outline-primary px-4">
                  <i className="bi bi-bookmark me-2"></i>Add to Wishlist
                </button>
                <button
                  className="btn btn-info px-4"
                  onClick={() => navigate(`/review/${book.bookId}`)}>
                  <i className="bi bi-chat-square-text me-2"></i> Write Review
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookDetails;
