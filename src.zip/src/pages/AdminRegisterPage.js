import React, { useState } from 'react';
import axios from 'axios';

const AdminRegisterPage = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: ''
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');

    try {
      const res = await axios.post('https://localhost:7093/api/Admin/register', formData);
      setMessage('Admin registered successfully!');
      console.log(res.data);
    } catch (error) {
      const backendData = error.response?.data;
      setMessage(backendData || 'Registration failed');
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4 text-center">Admin Register 👑</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit} className="border p-4 rounded shadow-sm">
        <div className="mb-3">
          <label>Full Name</label>
          <input type="text" name="fullName" className="form-control" value={formData.fullName} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Email</label>
          <input type="email" name="email" className="form-control" value={formData.email} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Password</label>
          <input type="password" name="password" className="form-control" value={formData.password} onChange={handleChange} required />
        </div>
        <button type="submit" className="btn btn-dark w-100">Register</button>
        <p className="mt-3 text-center">
          Already an admin? <a href="/">Login here</a>
        </p>

      </form>
    </div>
  );
};

export default AdminRegisterPage;
