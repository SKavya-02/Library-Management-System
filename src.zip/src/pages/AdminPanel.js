import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AdminPanel = () => {
  const [books, setBooks] = useState([]);
  const navigate = useNavigate();

  const fetchBooks = async () => {
    try {
      const token = localStorage.getItem("adminToken");
      const res = await axios.get("https://localhost:7093/api/Book/all", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBooks(res.data);
    } catch (err) {
      console.error(err);
      if (err.response?.status === 401) {
        alert("❌ Unauthorized! Please login again.");
        navigate("/admin/login");
      } else {
        alert("❌ Failed to fetch books");
      }
    }
  };

  const handleDelete = async (id) => {
    if (!id) return;
    if (!window.confirm("Are you sure you want to delete this book?")) return;

    try {
      const token = localStorage.getItem("adminToken");
      await axios.put(
        `https://localhost:7093/api/Book/softdelete/${id}`,
        null,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert("✅ Book deleted successfully!");
      fetchBooks(); // Refresh list
    } catch (err) {
      console.error(err);
      alert(err.response?.data || "❌ Failed to delete book");
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Admin Dashboard 📚</h2>
      <button
        onClick={() => navigate("/admin/add-book")}
        style={{ marginBottom: "20px" }}
      >
        ➕ Add New Book
      </button>

      <table
        border="1"
        cellPadding="10"
        style={{ width: "100%", borderCollapse: "collapse" }}
      >
        <thead style={{ backgroundColor: "#f0f0f0" }}>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Cost</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.length === 0 ? (
            <tr>
              <td colSpan="4" style={{ textAlign: "center" }}>
                No books found.
              </td>
            </tr>
          ) : (
            books.map((book) => (
              <tr key={book.id}>
                <td>{book.title}</td>
                <td>{book.author}</td>
                <td>{book.cost}</td>
                <td>
                  <button
                    onClick={() =>
                      navigate(`/admin/add-book?edit=${book.id}`)
                    }
                    style={{ marginRight: "10px" }}
                  >
                    ✏️ Edit
                  </button>
                  <button onClick={() => handleDelete(book.id)}>🗑️ Delete</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AdminPanel;
