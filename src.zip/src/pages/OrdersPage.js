import React from 'react';

const OrdersPage = () => {
  return (
    <div className="container mt-4">
      <h2>📦 My Orders</h2>
      <p>No orders placed yet. Borrow or reserve books to view orders here!</p>
    </div>
  );
};

export default OrdersPage;
