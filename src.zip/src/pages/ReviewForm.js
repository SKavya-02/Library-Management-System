import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const ReviewPage = () => {
  const { id } = useParams(); // bookId from URL
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState("");
  const [rating, setRating] = useState(5);

  // ✅ Get logged-in userId directly from localStorage (set it after login)
  const userId = localStorage.getItem("userId");  
  const token = localStorage.getItem("userToken");

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!userId) {
      alert("User ID not found. Please log in again.");
      return;
    }

    if (!feedback.trim()) {
      alert("Please enter feedback before submitting.");
      return;
    }

    try {
      const res = await axios.post(
        "https://localhost:7093/api/Review/add",
        {
          userId: Number(userId), // from localStorage
          bookId: Number(id),     // from URL
          feedback,
          rating: Number(rating),
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const msg =
        typeof res.data === "string"
          ? res.data
          : res.data.message || "Review added successfully!";

      alert(msg);
      navigate(`/books/${id}`);
    } catch (error) {
      console.error("Error adding review:", error);

      const errorMsg =
        typeof error.response?.data === "string"
          ? error.response?.data
          : error.response?.data?.message ||
            "Failed to submit review. Please try again.";

      alert(errorMsg);
    }
  };

  return (
    <div className="container py-4">
      <h2 className="mb-4">
        <i className="bi bi-chat-square-text me-2"></i>
        Submit Your Review
      </h2>

      <div className="card shadow-sm p-4">
        <form onSubmit={handleSubmit}>
          {/* Rating */}
          <div className="mb-3">
            <label className="form-label">Rating</label>
            <select
              className="form-select"
              value={rating}
              onChange={(e) => setRating(e.target.value)}
              required
            >
              {[1, 2, 3, 4, 5].map((r) => (
                <option key={r} value={r}>
                  {r} ⭐
                </option>
              ))}
            </select>
          </div>

          {/* Feedback */}
          <div className="mb-3">
            <label className="form-label">Feedback</label>
            <textarea
              className="form-control"
              rows="4"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Write your feedback here..."
              required
            ></textarea>
          </div>

          <button type="submit" className="btn btn-primary">
            <i className="bi bi-send me-2"></i>Submit Review
          </button>
        </form>
      </div>
    </div>
  );
};

export default ReviewPage;
