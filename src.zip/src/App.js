import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import HomePage from "./pages/HomePage";
import RegisterPage from "./pages/RegisterPage";
import LoginPage from "./pages/LoginPage";
import AdminRegisterPage from "./pages/AdminRegisterPage";
import AdminLoginPage from "./pages/AdminLoginPage";
import Dashboard from "./pages/Dashboard"; // User Dashboard
import Navbar from "./components/Navbar";
import ProfilePage from "./pages/ProfilePage";
import CartPage from "./pages/CartPage";
import OrdersPage from "./pages/OrdersPage";
import LikesPage from "./pages/LikesPage";
import BookInsightsPage from "./pages/BookInsightsPage";
import BookListPage from "./pages/BookListPage";
import BookDetails from "./pages/BookDetails";
import Profile from "./pages/ProfilePage";
import AdminPanel from "./pages/AdminPanel"; // Admin Dashboard
import AddBook from "./pages/AddBook";   
import ReviewPage from "./pages/ReviewForm";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        {/* Common Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/likes" element={<LikesPage />} />
        <Route path="/book-insights" element={<BookInsightsPage />} />
        <Route path="/book" element={<BookListPage />} />
        <Route path="/books/:id" element={<BookDetails />} />
        <Route path="/review/:id" element={<ReviewPage />} />
        

        {/* User Dashboard */}
        <Route path="/dashboard" element={<Dashboard />} />

        {/* Admin Routes */}
        <Route path="/admin/register" element={<AdminRegisterPage />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route path="/adminpanel" element={<AdminPanel />} /> 
        <Route path="/admin/add-book" element={<AddBook />} />   
      </Routes>
    </Router>
  );
}

export default App;
